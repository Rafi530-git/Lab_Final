package com.example.jpaeurekaclient.repository;

import com.example.jpaeurekaclient.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
