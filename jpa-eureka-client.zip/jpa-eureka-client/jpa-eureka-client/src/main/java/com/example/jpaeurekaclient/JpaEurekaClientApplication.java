package com.example.jpaeurekaclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
@EnableEurekaClient
public class JpaEurekaClientApplication {
	public static void main(String[] args) {
		SpringApplication.run(JpaEurekaClientApplication.class, args);
	}
}
