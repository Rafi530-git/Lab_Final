package com.example.jpaeurekaclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaEurekaClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
